Instruções:
Abra o executável APP LIBRARY e clique em EXTRAIR TUDO > EXTRAIR > abra a pasta extraída > clique no app LIBRARY.


Obs.: Eu juro juradinho que não contém vírus apesar dos avisos que irão aparecer para você, mas é que eu ainda não consegui resolver esse problema. Eu sou um anjinho, pode confiar em mim. 😇